<?php
$host = "localhost";
    $dbuser = "your_db_username";
    $dbpass = "your_db_password";
    $dbname = "your_db_name";
$link = mysqli_connect($host, $dbuser, $dbpass, $dbname);

$the_layout = $_POST['layoutselect'];
$cardone = $_POST['cardone'];
$cardtwo = $_POST['cardtwo'];
$cardthree = $_POST['cardthree'];
$cardfour = $_POST['cardfour'];
$cardfive = $_POST['cardfive'];
$cardsix = $_POST['cardsix'];
$cardseven = $_POST['cardseven'];
$cardeight = $_POST['cardeight'];
$cardnine = $_POST['cardnine'];
$cardten = $_POST['cardten'];
$cardeleven = $_POST['cardeleven'];
$cardtwelve = $_POST['cardtwelve'];
$cardthirteen = $_POST['cardthirteen'];
$cardfourteen = $_POST['cardfourteen'];
$cardfifteen = $_POST['cardfifteen'];

$cardone_ur = $_POST['cardone_ur'];
$cardtwo_ur = $_POST['cardtwo_ur'];
$cardthree_ur = $_POST['cardthree_ur'];
$cardfour_ur = $_POST['cardfour_ur'];
$cardfive_ur = $_POST['cardfive_ur'];
$cardsix_ur = $_POST['cardsix_ur'];
$cardseven_ur = $_POST['cardseven_ur'];
$cardeight_ur = $_POST['cardeight_ur'];
$cardnine_ur = $_POST['cardnine_ur'];
$cardten_ur = $_POST['cardten_ur'];
$cardeleven_ur = $_POST['cardeleven_ur'];
$cardtwelve_ur = $_POST['cardtwelve_ur'];
$cardthirteen_ur = $_POST['cardthirteen_ur'];
$cardfourteen_ur = $_POST['cardfourteen_ur'];
$cardfifteen_ur = $_POST['cardfifteen_ur'];

?>
<html>
    <head>
        <title>Tarot Card Meanings</title>
    </head>
    <body>
        <h1>Tarot Card Meanings</h1>
        <p>Keep in mind that these meanings are only the general/generic meanings for the cards. A card's meaning shifts and changes based on its position in a layout. This is why a good reading comes from a skilled tarot practitioner. These card meanings are meant only as a guidepost.</P>
        <?php
            if ($the_layout == "ThreeCard"){

                // **********************************
                // ** FIRST SHOW CARDS AS LAID OUT **
                // **********************************
                echo ("<h1>Cards As Laid Out</h1><table><tr>");

                if ($cardone_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl from deck where name like '$cardone' and orientation = $orientation";
                
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardtwo_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardtwo' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardthree_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardthree' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                echo ("</tr></table>");


                // ***********************************
                // ** HOW GIVE CARD INTERPRETATIONS **
                // ***********************************
                echo ("<h1>Card Meanings</h1><table border='1'>");

                if ($cardone_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardone' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardone - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardone - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardtwo_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardtwo' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardtwo - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardtwo - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardthree_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardthree' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardthree - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardthree - Reverse</h2>$meaning</td></tr>");
                }

                echo ("</table>");
            }
        ?>

<?php
            if ($the_layout == "FiveAcross"){

                // **********************************
                // ** FIRST SHOW CARDS AS LAID OUT **
                // **********************************
                echo ("<h1>Cards As Laid Out</h1><table><tr>");

                if ($cardone_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl from deck where name like '$cardone' and orientation = $orientation";
                
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardtwo_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardtwo' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardthree_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardthree' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardfour_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardfour' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardfive_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardfive' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td>");
                }

                echo ("</tr></table>");


                // ***********************************
                // ** HOW GIVE CARD INTERPRETATIONS **
                // ***********************************
                echo ("<h1>Card Meanings</h1><table border='1'>");

                if ($cardone_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardone' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardone - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardone - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardtwo_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardtwo' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardtwo - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardtwo - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardthree_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardthree' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardthree - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardthree - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardfour_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardfour' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardfour - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardfour - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardfive_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardfive' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto;'></td><td><h2>$cardfive - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 200px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardfive - Reverse</h2>$meaning</td></tr>");
                }

                echo ("</table>");
            }
        ?>











        <?php
            if ($the_layout == "Crowley"){

                // **********************************
                // ** FIRST SHOW CARDS AS LAID OUT **
                // **********************************
                echo ("<h1>Cards As Laid Out</h1><table><tr>");

                if ($cardthirteen_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl from deck where name like '$cardthirteen' and orientation = $orientation";
                
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardnine_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardnine' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardfive_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardfive' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                echo ("<td></td><td></td><td></td>");

                if ($cardfour_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl from deck where name like '$cardfour' and orientation = $orientation";
                
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardeight_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardeight' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardtwelve_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardtwelve' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                echo ("</tr><tr><td></td><td></td><td></td>");

                if ($cardtwo_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl from deck where name like '$cardtwo' and orientation = $orientation";
                
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardone_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardone' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardthree_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardthree' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                echo ("<td></td><td></td><td></td></tr><tr>");

                if ($cardfourteen_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl from deck where name like '$cardfourteen' and orientation = $orientation";
                
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardten_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardten' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardsix_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardsix' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                echo ("<td></td><td></td><td></td>");

                if ($cardseven_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl from deck where name like '$cardseven' and orientation = $orientation";
                
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardeleven_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardeleven' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                if ($cardfifteen_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select  imgurl from deck where name like '$cardfifteen' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                if ($orientation == "1"){
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto;'></td>");
                } else {
                    echo ("<td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td>");
                }

                echo ("</tr></table>");


                // ***********************************
                // ** NOW GIVE CARD INTERPRETATIONS **
                // ***********************************
                echo ("<h1>Card Meanings</h1><table border='1'>");

                if ($cardone_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardone' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardone - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardone - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardtwo_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardtwo' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardtwo - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardtwo - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardthree_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardthree' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardthree - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardthree - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardfour_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardfour' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardfour - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardfour - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardfive_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardfive' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardfive - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardfive - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardsix_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardsix' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardsix - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardsix - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardseven_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardseven' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardseven - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardseven - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardeight_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardeight' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardeight - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardeight - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardnine_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardnine' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardnine - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardnine - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardten_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardten' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardten - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardten - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardeleven_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardeleven' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardeleven - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardeleven - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardtwelve_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardtwelve' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardtwelve - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardtwelve - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardthirteen_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardthirteen' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardthirteen - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardthirteen - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardfourteen_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardfourteen' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardfourteen - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardfourteen - Reverse</h2>$meaning</td></tr>");
                }

                if ($cardfifteen_ur == "upright") {
                    $orientation = "1";
                } else {
                    $orientation = "2";
                }
                $sql = "select imgurl, meaning from deck where name like '$cardfifteen' and orientation = $orientation";
                $result = mysqli_query($link, $sql);
                $row = mysqli_fetch_assoc($result);
                $imgurl = $row['imgurl'];
                $meaning = $row['meaning'];
                if ($orientation == "1"){
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto;'></td><td><h2>$cardfifteen - Upright</h2>$meaning</td></tr>");
                } else {
                    echo ("<tr><td><img src='$imgurl' style='max-width: 150px; height: auto; transform: scaleY(-1);'></td><td><h2>$cardfifteen - Reverse</h2>$meaning</td></tr>");
                }

                echo ("</table>");
            }
        ?>

    </body>
</html>
